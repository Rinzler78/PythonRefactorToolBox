from typing import List


class Tati:
    str_list: List[str] = None
