def greet():
    print('Hello, world!')
