from .mod1 import MyClass


class AnotherClass:

    def method_two(self):
        obj = MyClass()
        obj.method_one()
