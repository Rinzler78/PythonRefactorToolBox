class MyClass:

    def method_one(self):
        print('Method One')
