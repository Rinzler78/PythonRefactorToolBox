from typing import List


class Toto:
    str_list= List[str] = None