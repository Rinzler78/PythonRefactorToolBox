from modules.mod1 import MyClass
from .my_main_class import MyMainClass
from utils.helper import greet


def another_func():
    print('Another Function')
    return MyMainClass()


def main():
    greet()
    obj = MyClass()
    obj.method_one()
    my_main_class = another_func()


if __name__ == '__main__':
    main()
