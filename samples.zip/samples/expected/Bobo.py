from .Tati import Tati


class Bobo:
    tati: Tati = None
