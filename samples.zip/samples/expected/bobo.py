from .tati import Tati


class Bobo:
    tati: Tati = None
