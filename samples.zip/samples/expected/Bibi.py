from .Bobo import Bobo


class Bibi:
    bobo: Bobo = None
