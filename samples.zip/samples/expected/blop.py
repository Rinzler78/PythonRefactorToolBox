from .toto import Toto
from .tata import Tata


def get_new_tata() -> Tata:
    return Tata()


toto: Toto = Toto()
