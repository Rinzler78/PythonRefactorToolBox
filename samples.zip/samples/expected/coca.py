from .baba import Baba
baba: Baba = Baba()
