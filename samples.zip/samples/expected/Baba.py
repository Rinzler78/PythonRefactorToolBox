from .Toto import Toto
from typing import List


class Baba:
    toto: Toto = None
    str_list: List[str] = None
