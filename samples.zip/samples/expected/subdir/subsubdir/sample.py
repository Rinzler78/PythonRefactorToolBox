from modules.mod1 import MyClass


def run():
    obj = MyClass()
    obj.method_one()
