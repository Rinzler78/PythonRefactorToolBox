from .bobo import Bobo


class Bibi:
    bobo: Bobo = None
