from typing import List

from .Baba import Baba

class Tata:
    baba:Baba = None
    str_list= List[str] = None