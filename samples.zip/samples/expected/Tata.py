from .Baba import Baba


class Tata:
    baba: Baba = None
