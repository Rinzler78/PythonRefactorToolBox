from .baba import Baba


class Tata:
    baba: Baba = None
