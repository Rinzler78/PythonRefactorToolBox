class MyMainClass:

    def method_one(self):
        txt: str = 'Method One'
        print(txt)
        return txt
