from .tata import Tata
from .toto import Toto


def get_new_tata() -> Tata:
    return Tata()


toto: Toto = Toto()
