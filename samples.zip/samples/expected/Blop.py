from .Toto import Toto
from .Tata import Tata


def get_new_tata() -> Tata:
    return Tata()


toto: Toto = Toto()
