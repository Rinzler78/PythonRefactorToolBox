from .bobo import Bobo
bobo: Bobo = Bobo()
