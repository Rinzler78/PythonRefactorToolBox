from typing import List
from .Toto import Toto

class Baba :
    toto:Toto = None
    str_list= List[str] = None

class Tata:
    baba:Baba = None
    str_list= List[str] = None