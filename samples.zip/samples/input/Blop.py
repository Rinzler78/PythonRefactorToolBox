from typing import List
from .Bobo import Bobo


class Toto:
    str_list = List[str] = None


class Baba:
    toto: Toto = None
    str_list: List[str] = None


class Bibi:
    bobo: Bobo = None


class Tata:
    baba: Baba = None


def get_new_tata() -> Tata:
    return Tata()


toto: Toto = Toto()